#! /bin/bash

cd ./roles/rhel8

aar_doc . markdown

cd ../rhel9

aar_doc . markdown

cd ../windows2019

aar_doc . markdown

cd ../windows2022

aar_doc . markdown
