# ansible-collection-cis
This collection contains roles for applying CIS Benchmarks to various systems.
